<?php
include "header.php";
include "content.php";
include "footer.php";
include "script.js";
?>