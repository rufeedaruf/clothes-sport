<?php
include "header.php";
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
</div>
<!--Cart Items Details -->
<div class="small-container cart-page">
    <table>
        <tr>
            <th>Produact</th>
            <th>Quantity</th>
            <th>Subtotal</th>
</tr>
<tr>
<td>
    
    <div class="cart-info">

        <img src="images/buy-1.jpg">
        <div>

            <p> Red Printed Tshirt </p>
            <small> Price: $50.00 </small>
            <br>
            <a href="">Remove</a>
</div>
</div>
</td>



    <td><input type="number" value="1"></td>
    <td>$50.00</td>

</tr>
<tr>
<td>
    
    <div class="cart-info">

        <img src="images/buy-2.jpg">
        <div>

            <p> Red Printed Tshirt </p>
            <small> Price: $75.00 </small>
            <br>
            <a href="">Remove</a>
</div>
</div>
</td>

    <td><input type="number" value="1"></td>
    <td>$75.00</td>
</tr>
<tr>
<td>
    
    <div class="cart-info">

        <img src="images/buy-3.jpg">
        <div>

            <p> Red Printed Tshirt </p>
            <small> Price: $75.00 </small>
            <br>
            <a href="">Remove</a>
</div>
</div>
</td>



    <td><input type="number" value="1"></td>
    <td>$75.00</td>

</tr>
</table>
<div class="total-price">
    <table> 
        <tr>
            <td>Subtotal</td>
            <td>$200.00</td>
</tr>
<tr>
            <td>Tax</td>
            <td>$35.00</td>
</tr>
<tr>
            <td>Total</td>
            <td>$335.00</td>
</tr>


    </table>
</div>
</div> 
</body>
</html>
<?php

include "footer.php";
?>