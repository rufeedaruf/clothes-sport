<?php
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link
     href="https://fonts.googleapis.com/css2?family=Exo+2:wght@200&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <title>My Store</title>
</head>
<body>
<div class="header">
<div class="row">
<div class="col-2">
    <h1>Give Your Worhout<br> A New Style!</h1>
    <p>Success isn't always about greatness. it's about 
        consistency.consistant<br> hard work gains success. greatness
        will come.
    </p>
    <a href="" class="btn">Explore Now &#8594; </a>

</div>
<div class="col-2">
    <img src="images/image1.png" alt="">

</div>
</div>
</div>
</div>
</div>
<!---------featured categories--->
<div class="categorise">
<div class="small-container">
<div class="row">
<div class="col-3">
<img src="images/category-1.jpg">
</div>
<div class="col-3">
<img src="images/category-2.jpg">
</div>
<div class="col-3">
<img src="images/category-3.jpg">
</div>
</div>
</div>
</div>
<!--------End featured categories--->


<!---------featured Products--->
<div class="small-container">
<h2 class="tittle">Featured Products</h2>
<div class="row">
<div class="col-4">
    <img src="images/product-1.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-2.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-3.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-4.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
</div>
<h2 class="tittle">Latest Products</h2>
<div class="row">
<div class="col-4">
    <img src="images/product-5.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-6.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-7.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-8.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-9.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-10.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-11.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-12.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
</div>

</div>
<!--Offer-->
<div class="offer">
<div class="small-container">

<div class="row">
    <div class="col-2">
        <img src="images/exclusive.png" class="offer-img">
    </div>
    <div class="col-2">
        <p>Exclusively Available On Red Store</p>
        <h1>Smart Band</h1>
        <small>This My Smart Band 4 Features 39.9% larger 
            (Than mi Band3) AMOLED color full-touch display with 
            adjustable brightness, So everything is clear  as can be.
        </small>
        <a href="" class="btn">Buy Now &#8594; </a>
    </div>
</div>
</div>
</div>
</div>


<!--testimonial-->
<div class="testimonial">
<div class="small-container">
<div class="row">
    <div class="col-3">
        <i class="fa fa-quote-left"></i>
        <p>
            What is Lorem Ipsum?
            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
            </p>
         
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <img src="images/user-1.png">
            <h3>Sean Parker</h3>

</div>

    <div class="col-3">
        <i class="fa fa-quote-left"></i>
        <p>
            What is Lorem Ipsum?
            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
            </p>
         
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <img src="images/user-2.png">
            <h3>Mike Smith</h3>
    </div>

    <div class="col-3">
        <i class="fa fa-quote-left"></i>
        <p>
            What is Lorem Ipsum?
            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
             Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
            </p>
         
            <div class="rating">
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star-o"></i>
            </div>
            <img src="images/user-3.png">
            <h3>Mabel Joe</h3>
  
</div>
</div>
</div>

<!--brands-->
<div class="brands">
<div class="small-container">
<div class="row">
    <div class="col-5">
        <img src="images/logo-godrej.png">
    </div>
    <div class="col-5">
        <img src="images/logo-oppo.png">
    </div>
    <div class="col-5">
        <img src="images/logo-coca-cola.png">
    </div>
    <div class="col-5">
        <img src="images/logo-paypal.png">
    </div>
    <div class="col-5">
        <img src="images/logo-philips.png">
    </div>
</div>

<div class="page-btn">
    <span>1</span>
    <span>2</span>
    <span>3</span>
    <span>4</span>
    <span>5   &#8594;</span>
</div>
</div>
</div>



