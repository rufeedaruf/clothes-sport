<?php 
include "header.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
</div>

<!--Single Product-->
<div class="small-container single-product">
    <div class="row">
        <div class="col-2">
            <img src="images/gallery-1.jpg" width="100%" id="product-img">

        <div class="small-img-row">
            <div class="small-img-col">
                <img src="images/gallery-1.jpg" width="100%" class="small-img">
            </div>
            <div class="small-img-col">
                <img src="images/gallery-2.jpg" width="100%" class="small-img">
            </div>
            <div class="small-img-col">
                <img src="images/gallery-3.jpg" width="100%" class="small-img">
            </div>
            <div class="small-img-col">
                <img src="images/gallery-4.jpg" width="100%" class="small-img">
            </div>

        </div>
        </div>

        <div class="col-2">
            <p> Home / T-Shirt</p>
            <h1>Red Printed T-Shirt By HRX</h1>
            <h4>$50.00</h4>
            <select>
                <option>Select Size</option>
                <option>XXL</option>
                <option>XL</option>
                <option>Large</option>
                <option>Medium </option>
                <option>Small</option>
            </select>
            <input type="number" value="1">
            <a href="" class="btn"> Add To Cart </a>
            <h3>Product Details<i class="fa fa-indent"></i></h3>
            <br>
            <p> Product Details Product Details  Product Details 
            Product DetailsProduct DetailsProduct Details<br>
            Product DetailsProduct DetailsProduct DetailsProduct Details </p>
        </div>
    </div>
</div>

</div>
<br>
<div class="small-container">
    <div class="row">
        <h2>Related Products </h2>
        <p>View More </p>

    </div>
</div>
<br>
<br>

<div class="small-container">
<h2 class="tittle">Featured Products</h2>
<div class="row">
<div class="col-4">
    <img src="images/product-9.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-2.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
<div class="col-4">
    <img src="images/product-3.jpg">
    <h4>Red Printed T-shirt</h4>
    <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half-o"></i>
    </div>
    <p>50.00$</p>
</div>
</div>
</div> 
</body>
</html>
<?php 
include "footer.php";




?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<script src="script2.js">
   

</script>
    
</body>
</html>