<?php 
include "header.php";
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!--account-page-->
<div class="account-page">
    <div class="container">
        <div class="row">
            <div class="col-2">
                <img src="images/image1.png" width="100%">
            </div>
            <div class="col-2">
                <div class="form-container">
                    <div class="form-btn">
                        <span>Login <span>
                        <span>Register <span>
                    </div>
                    <form id="loginform"> 
                        <input type="text" placeholder="Username">
                        <input type="password" placeholder="Password">
                        <button type="submit" class="btn">Login </button>
                        <a href="">Forget Password</a>
                    </form>
                    <form id="regform"> 
                        <input type="text" placeholder="Username">
                        <input type="email" placeholder="email">
                        <input type="password" placeholder="Password">
                        <button type="submit" class="btn">Register</button>
                     
                    </form>

                </div>
               
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php 
include "footer.php";
?>


